package com.hcl.onlineShopping.responseModel;

import java.util.List;

import com.hcl.onlineShopping.entity.WishList;

public class WishListResponse {

	private WishList wishList;
	private List<WishList> MyWishList;
	private String message;
	private String statusMessage;
	private String StatusCode;

	public WishList getWishList() {
		return wishList;
	}

	public void setWishList(WishList wishList) {
		this.wishList = wishList;
	}

	public List<WishList> getMyWishList() {
		return MyWishList;
	}

	public void setMyWishList(List<WishList> myWishList) {
		MyWishList = myWishList;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getStatusMessage() {
		return statusMessage;
	}

	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}

	public String getStatusCode() {
		return StatusCode;
	}

	public void setStatusCode(String statusCode) {
		StatusCode = statusCode;
	}

}
