package com.hcl.onlineShopping.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.hcl.onlineShopping.entity.Order;
import com.hcl.onlineShopping.responseModel.OrderResponse;
import com.hcl.onlineShopping.service.MyOrderService;
@CrossOrigin
@RestController
public class MyOrderController {
	private static final Logger logger = LoggerFactory.getLogger(MyOrderController.class);
	@Autowired
	MyOrderService myOrderService;

	@GetMapping(value = "/myorder")
	public OrderResponse showMyOrder(@RequestParam int id) {
		logger.debug("Start of MyOrderController");
		List<Order> myOrderList = myOrderService.myOrdercheck(id);
		OrderResponse myOrderResponse = new OrderResponse();
		myOrderResponse.setOrderList(myOrderList);
		myOrderResponse.setMessage("My Orders");
		myOrderResponse.setStatusCode("200");
		myOrderResponse.setStatusMessage("OK");
		logger.debug("End of MyOrderController");

		return myOrderResponse;
	}
}
