package com.bank.application.bankapplication.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bank.application.bankapplication.entity.Employee;

@Repository
public interface BankEmployeeRepository extends JpaRepository<Employee, Integer> {

}
