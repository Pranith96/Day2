package com.hcl.onlineShopping.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.hcl.onlineShopping.entity.Product;
import com.hcl.onlineShopping.responseModel.ProductResponse;
import com.hcl.onlineShopping.service.ProductDetailsService;
@CrossOrigin
@RestController
public class ProductDetailsController {
	private static final Logger logger = LoggerFactory.getLogger(ProductDetailsController.class);
	@Autowired
	ProductDetailsService productDetailsService;

	@GetMapping(value = "/product/details")
	public ProductResponse getOffers(@RequestParam int productId) {
		logger.debug("Start of ProductDetailsController");
		Product productDetails = productDetailsService.productCheck(productId);
		ProductResponse productResponse = new ProductResponse();
		productResponse.setProduct(productDetails);
		productResponse.setMessage(" products details");
		productResponse.setStatusCode("200");
		productResponse.setStatusMessage("OK");
		logger.debug("End of ProductDetailsController");
		return productResponse;
	}
}
