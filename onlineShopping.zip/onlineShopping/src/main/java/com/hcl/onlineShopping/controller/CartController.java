package com.hcl.onlineShopping.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.hcl.onlineShopping.entity.Cart;
import com.hcl.onlineShopping.responseModel.CartResponse;
import com.hcl.onlineShopping.service.CartService;
@CrossOrigin
@RestController

public class CartController {

	private static final Logger logger = LoggerFactory.getLogger(CartController.class);

	@Autowired
	CartService cartService;

	@PostMapping(value = "/cart/add")
	public CartResponse showCart(@RequestBody Cart cart) {
		logger.debug("Start of Cart Controller");
		Cart responseCart = cartService.saveCart(cart);
		CartResponse cartResponse = new CartResponse();
		cartResponse.setCart(responseCart);
		cartResponse.setMessage("Added to cart");
		cartResponse.setStatusCode("200");
		cartResponse.setStatusMessage("OK");
		logger.debug("end of Cart Controller");
		return cartResponse;

	}
}
