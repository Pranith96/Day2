package com.hcl.onlineShopping.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.hcl.onlineShopping.entity.Category;
import com.hcl.onlineShopping.responseModel.UserResponse;
import com.hcl.onlineShopping.service.CategoryService;


@CrossOrigin
@RestController

public class CategoryController {

	private static final Logger logger = LoggerFactory.getLogger(CategoryController.class);

	@Autowired
	CategoryService categoryService;
	@RequestMapping(value = "/admin")
	@PostMapping(value = "/category/add")
	public UserResponse saveCategory(@RequestBody Category category) {
		logger.debug("Start of category Controller");
		Category responseCategory = categoryService.saveCategory(category);
		UserResponse categoryResponse = new UserResponse();
		categoryResponse.setCategory(responseCategory);
		categoryResponse.setMessage("Category Added");
		categoryResponse.setStatusCode("200");
		categoryResponse.setStatusMessage("OK");
		logger.debug("end of Category Controller");
		return categoryResponse;
	}
	
	@GetMapping(value = "/category/display")
	public UserResponse displayCategory() {
		logger.debug("Start of category Controller");
		List<Category> responseCategory = categoryService.displayCategory();
		UserResponse categoryResponse = new UserResponse();
		categoryResponse.setCategoryList(responseCategory);
		categoryResponse.setMessage("Category List");
		categoryResponse.setStatusCode("200");
		categoryResponse.setStatusMessage("OK");
		logger.debug("end of category Controller");
		return categoryResponse;
	}
}
