package com.hcl.onlineShopping.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.onlineShopping.entity.User;
import com.hcl.onlineShopping.responseModel.UserResponse;
import com.hcl.onlineShopping.service.RegistrationService;

@CrossOrigin
@RestController
public class RegistrationController {
	private static final Logger logger = LoggerFactory.getLogger(RegistrationController.class);

	@Autowired
	RegistrationService registrationService;

	@PostMapping(value = "/register/save")
	public UserResponse saveUser(@RequestBody User user) {
		logger.debug("Start of RegistrationController");
		User responseUser = registrationService.saveUser(user);
		UserResponse userResponse = new UserResponse();
		userResponse.setUser(responseUser);
		userResponse.setMessage("Registration Success");
		userResponse.setStatusCode("200");
		userResponse.setStatusMessage("OK");
		logger.debug("End of RegistrationController");
		return userResponse;

	}
}
