package com.hcl.onlineShopping.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.hcl.onlineShopping.entity.User;
import com.hcl.onlineShopping.repository.RegistrationRepository;

@Service
public class RegistrationService {
	private static final Logger logger = LoggerFactory.getLogger(RegistrationService.class);
	@Autowired
	RegistrationRepository registrationRepository;

	public User saveUser(User user) {
		logger.debug("In RegistrationService");
		return registrationRepository.save(user);
	}

}
