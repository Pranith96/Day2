package com.hcl.onlineShopping.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.hcl.onlineShopping.entity.DeliveryDetails;
import com.hcl.onlineShopping.repository.DeliveryDetailsRepository;

@Service
public class DeliveryDetailsService {
	private static final Logger logger = LoggerFactory.getLogger(DeliveryDetailsService.class);
	@Autowired
	DeliveryDetailsRepository deliveryDetailsRepository;

	public DeliveryDetails saveDeliveryDetails(DeliveryDetails deliveryDetails) {
		logger.debug("In DeliveryDetailsService");
		return deliveryDetailsRepository.save(deliveryDetails);
	}

}
