package com.hcl.onlineShopping.responseModel;

import java.util.List;

import com.hcl.onlineShopping.entity.Cart;

public class CartResponse {

	private Cart cart;
	private List<Cart> CartList;
	private String message;
	private String statusMessage;
	private String StatusCode;

	public Cart getCart() {
		return cart;
	}

	public void setCart(Cart cart) {
		this.cart = cart;
	}

	public List<Cart> getCartList() {
		return CartList;
	}

	public void setCartList(List<Cart> cartList) {
		CartList = cartList;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getStatusMessage() {
		return statusMessage;
	}

	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}

	public String getStatusCode() {
		return StatusCode;
	}

	public void setStatusCode(String statusCode) {
		StatusCode = statusCode;
	}

}
