package com.hcl.onlineShopping.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.hcl.onlineShopping.entity.Category;
import com.hcl.onlineShopping.entity.User;
import com.hcl.onlineShopping.repository.CategoryRepository;
import com.hcl.onlineShopping.repository.RegistrationRepository;

@Service
public class LoginService {
	private static final Logger logger = LoggerFactory.getLogger(LoginService.class);
	@Autowired
	RegistrationRepository registrationRepository;
	@Autowired
	CategoryRepository categoryRepository;

	public List<User> getUser(String username, String password) {
		logger.debug("In LoginService");
		return registrationRepository.findByUsernameAndPassword(username, password);
	}

	public List<Category> getCategories(Category category) {
		logger.debug("In Category");
		return categoryRepository.findAll();
	}

}
