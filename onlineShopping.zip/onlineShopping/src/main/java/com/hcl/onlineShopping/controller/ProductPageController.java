package com.hcl.onlineShopping.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.hcl.onlineShopping.entity.Product;
import com.hcl.onlineShopping.responseModel.ProductResponse;
import com.hcl.onlineShopping.service.ProductPageService;
@CrossOrigin
@RestController
public class ProductPageController {

	private static final Logger logger = LoggerFactory.getLogger(ProductPageController.class);

	@Autowired
	ProductPageService productService;

	@GetMapping(value = "/products/page")
	public ProductResponse showProducts(@RequestParam int categoryId) {
		logger.debug("Start of ProductPageController");
		List<Product> productList = productService.productCheck(categoryId);
		ProductResponse responseProductList = new ProductResponse();
		responseProductList.setProductList(productList);
		responseProductList.setMessage("Products List");
		responseProductList.setStatusCode("200");
		responseProductList.setStatusMessage("OK");
		logger.debug("End of ProductPageController");
		return responseProductList;
	}

}
