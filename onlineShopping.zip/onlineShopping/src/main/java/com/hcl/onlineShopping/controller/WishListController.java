package com.hcl.onlineShopping.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.hcl.onlineShopping.entity.WishList;
import com.hcl.onlineShopping.responseModel.WishListResponse;
import com.hcl.onlineShopping.service.WishListService;
@CrossOrigin
@RestController

public class WishListController {
	private static final Logger logger = LoggerFactory.getLogger(WishListController.class);

	@Autowired
	WishListService wishListService;

	@PostMapping(value = "/wishlist")
	public WishListResponse showWishList(@RequestBody WishList wishList) {
		logger.debug("Start of WishListController");
		WishList responseWishList = wishListService.saveWishList(wishList);
		WishListResponse wishListResponse = new WishListResponse();
		wishListResponse.setWishList(responseWishList);
		wishListResponse.setMessage("Added to wishList");
		wishListResponse.setStatusCode("200");
		wishListResponse.setStatusMessage("OK");
		logger.debug("End of WishListController");
		return wishListResponse;

	}
}
