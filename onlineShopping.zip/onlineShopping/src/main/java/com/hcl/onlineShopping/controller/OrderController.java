package com.hcl.onlineShopping.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.hcl.onlineShopping.entity.Order;
import com.hcl.onlineShopping.responseModel.OrderResponse;
import com.hcl.onlineShopping.service.OrderService;

@CrossOrigin
@RestController
public class OrderController {
	private static final Logger logger = LoggerFactory.getLogger(OrderController.class);
	@Autowired
	OrderService orderService;
	
	@PostMapping(value="/Order")
	public OrderResponse showOrder(@RequestBody Order order) {
		logger.debug("Start of OrderController");
		Order responseOrder = orderService.saveOrder(order);
		OrderResponse OrderResponse = new OrderResponse();
		OrderResponse.setOrder(responseOrder);
		OrderResponse.setMessage("Order List");
		OrderResponse.setStatusCode("200");
		OrderResponse.setStatusMessage("OK");
		logger.debug("End of OrderController");
		return OrderResponse;
			
	}
}
