package com.hcl.onlineShopping.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.hcl.onlineShopping.entity.Product;
import com.hcl.onlineShopping.repository.ProductRepository;

@Service
public class ProductPageService {
	private static final Logger logger = LoggerFactory.getLogger(ProductPageService.class);
	@Autowired
	ProductRepository productRepository;

	public List<Product> productCheck(int categoryId) {
		logger.debug("In ProductPageService");
		return productRepository.findAllBycategoryId(categoryId);
	}

}
