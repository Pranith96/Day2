package com.hcl.onlineShopping.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.hcl.onlineShopping.entity.Cart;
import com.hcl.onlineShopping.repository.CartRepository;

@Service
public class MyCartService {
	private static final Logger logger = LoggerFactory.getLogger(MyCartService.class);
	@Autowired
	CartRepository cartRepository;

	public List<Cart> myCartcheck(int id) {
		logger.debug("In MyCartService");
		return cartRepository.findAllById(id);
	}
}
