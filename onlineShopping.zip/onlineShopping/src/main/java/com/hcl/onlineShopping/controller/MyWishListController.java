package com.hcl.onlineShopping.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.hcl.onlineShopping.entity.WishList;
import com.hcl.onlineShopping.responseModel.WishListResponse;
import com.hcl.onlineShopping.service.MyWishListService;
@CrossOrigin
@RestController
public class MyWishListController {
	private static final Logger logger = LoggerFactory.getLogger(MyWishListController.class);
	@Autowired
	MyWishListService myWishListService;

	@GetMapping(value = "/mywishlist")
	public WishListResponse showMyCart(@RequestParam int id) {
		logger.debug("Start of MyWishListController");
		List<WishList> myWishList = myWishListService.myWishListcheck(id);
		WishListResponse myWishListResponse = new WishListResponse();
		myWishListResponse.setMyWishList(myWishList);
		myWishListResponse.setMessage("My WishList");
		myWishListResponse.setStatusCode("200");
		myWishListResponse.setStatusMessage("OK");
		logger.debug("End of MyWishListController");
		return myWishListResponse;

	}

}
