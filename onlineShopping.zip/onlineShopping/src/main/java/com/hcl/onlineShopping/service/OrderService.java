package com.hcl.onlineShopping.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.hcl.onlineShopping.entity.Order;
import com.hcl.onlineShopping.repository.OrderRepository;

@Service
public class OrderService {
	private static final Logger logger = LoggerFactory.getLogger(OrderService.class);
	@Autowired
	OrderRepository orderRepository;

	public Order saveOrder(Order order) {
		logger.debug("In OrderService");
		return orderRepository.save(order);
	}

}
