//package com.bank.application.bankapplication.config.security;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.http.HttpMethod;
//import org.springframework.security.authentication.AuthenticationManager;
//import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.config.annotation.web.builders.WebSecurity;
//import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
//import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
//import org.springframework.security.core.userdetails.UserDetailsService;
//
//import com.bank.application.bankapplication.config.PasswordConfig;
//import com.bank.application.bankapplication.entity.Roles;
//
//@Configuration
//@EnableWebSecurity
//public class WebSecurityAuthentication extends WebSecurityConfigurerAdapter {
//
//	@Autowired
//	PasswordConfig securityConfig;
//
//	@Autowired
//	UserDetailsService secureUserDetailsService;
//
//	public AuthenticationManager aunthenticationManager() throws Exception {
//
//		return super.authenticationManager();
//	}
//
//	protected void configure(AuthenticationManagerBuilder authentication) throws Exception {
//		authentication.userDetailsService(secureUserDetailsService).passwordEncoder(securityConfig.passwordEncoder());
//	}
//
//	protected void configure(HttpSecurity http) throws Exception {
//		http.cors().disable();
//		http.csrf().disable();
//		http.authorizeRequests().antMatchers(HttpMethod.POST, "/api/customer/register").permitAll()
//				.antMatchers(HttpMethod.POST, "/api/bank/send/amount/to")
//				.hasAnyRole(Roles.MANAGER.code(), Roles.EMPLOYEE.code(), Roles.USER.code())
//				.antMatchers(HttpMethod.POST, "/api/bank/login")
//				.hasAnyRole(Roles.MANAGER.code(), Roles.EMPLOYEE.code(), Roles.USER.code())
//				.antMatchers(HttpMethod.POST, "/api/bank/employee/register").hasAnyRole(Roles.MANAGER.code())
//				.antMatchers(HttpMethod.POST, "/api/bank/manager/register").hasAnyRole(Roles.MANAGER.code())
//				.antMatchers(HttpMethod.POST, "/api/bank/amount/**")
//				.hasAnyRole(Roles.MANAGER.code(), Roles.EMPLOYEE.code())
//				.antMatchers(HttpMethod.POST, "/api/bank/account/create")
//				.hasAnyRole(Roles.MANAGER.code(), Roles.EMPLOYEE.code()).antMatchers(HttpMethod.PUT)
//				.hasAnyRole(Roles.MANAGER.code(), Roles.EMPLOYEE.code()).antMatchers(HttpMethod.DELETE)
//				.hasAnyRole(Roles.MANAGER.code(), Roles.EMPLOYEE.code()).antMatchers(HttpMethod.GET)
//				.hasAnyRole(Roles.MANAGER.code(), Roles.EMPLOYEE.code(), Roles.USER.code());
//		// .antMatchers(HttpMethod.GET, "/v1/users/{userName}")
//		// .access("@userSecurity.hasUserId(authentication,#userName)");
//
//		
//		http.headers().frameOptions().disable();
//
//		super.configure(http);
//	}
//
//	public void configure(WebSecurity web) throws Exception {
//		web.ignoring().antMatchers("/v2/api-docs", "/configuration/ui", "/swagger-resources/**",
//				"/configuration/security", "/swagger-ui.html", "/webjars/**");
//	}
//}
