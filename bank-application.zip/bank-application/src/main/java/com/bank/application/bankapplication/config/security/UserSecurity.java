//package com.bank.application.bankapplication.config.security;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.core.Authentication;
//import org.springframework.stereotype.Component;
//
//import com.bank.application.bankapplication.entity.User;
//import com.bank.application.bankapplication.repository.UserRepository;
//
//@Component("userSecurity")
//public class UserSecurity {
//
//	@Autowired
//	UserRepository userRepository;
//
//	public boolean hasUserId(Authentication authentication, String userName) {
//
//		User userResponse = userRepository.findByUserName(authentication.getName());
//		String username = userResponse.getUserName();
//		System.out.println(username+"  "+userName);
//		if (username == userName)
//			return true;
//
//		return false;
//
//	}
//
//}
