package com.bank.application.bankapplication.resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bank.application.bankapplication.entity.User;
import com.bank.application.bankapplication.service.LoginService;
import com.bank.application.bankapplication.util.BanksConstants;

@RestController
@RequestMapping("/bank")
public class LoginController {

	private final LoginService loginService;

	@Autowired
	public LoginController(LoginService loginService) {
		this.loginService = loginService;
	}

	@PostMapping(value = "/login")
	public ResponseEntity<String> loginCustomer(@RequestBody User user) throws Exception {

		String userName = user.getUserName();
		String password = user.getPassword();

		loginService.loginCustomer(userName, password);

		return ResponseEntity.status(HttpStatus.OK).body(BanksConstants.LOGIN_SUCCESFULL);
	}
}
