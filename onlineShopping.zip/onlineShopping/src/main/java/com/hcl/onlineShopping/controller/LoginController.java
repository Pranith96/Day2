package com.hcl.onlineShopping.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.onlineShopping.entity.Category;
import com.hcl.onlineShopping.entity.User;
import com.hcl.onlineShopping.responseModel.UserResponse;
import com.hcl.onlineShopping.service.LoginService;

@CrossOrigin
@RestController

public class LoginController {

	private static final Logger logger = LoggerFactory.getLogger(LoginController.class);
	@Autowired
	LoginService loginservice;

	@PostMapping(value = "/login")
	public UserResponse getUsersByUsernameAndPassword(@RequestBody User user, Category category) {
		logger.debug("Start of Login Controller");
		String username = user.getUsername();
		String password = user.getPassword();
		List<User> users = loginservice.getUser(username, password);
		List<Category> categoryDetails = loginservice.getCategories(category);

		if (users.size() > 0) {
			UserResponse userResponse = new UserResponse();
			userResponse.setUser(users.get(0));
			userResponse.setCategoryList(categoryDetails);
			userResponse.setMessage("Welcome to online Store" + username);
			userResponse.setStatusCode("200");
			userResponse.setStatusMessage("Ok");
			logger.debug("End of Login Controller");
			return userResponse;

		} else {

			UserResponse userResponse = new UserResponse();
			userResponse.setUser(null);
			userResponse.setMessage("login failed");
			userResponse.setStatusCode("200");
			userResponse.setStatusMessage("OK");
			logger.debug("End of Login Controller");
			return userResponse;

		}

	}
}
