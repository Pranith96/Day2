package com.hcl.onlineShopping.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.hcl.onlineShopping.entity.Product;
import com.hcl.onlineShopping.responseModel.ProductResponse;
import com.hcl.onlineShopping.service.ProductService;
@CrossOrigin
@RestController
@RequestMapping(value="/admin")
public class ProductController {
	private static final Logger logger = LoggerFactory.getLogger(ProductController.class);
	@Autowired
	ProductService productService;
	
	@PostMapping(value = "/product/add")
	public ProductResponse saveProduct(@RequestBody Product product){
		logger.debug("Start of ProductController");
		Product responseProduct=productService.saveProduct(product);
		ProductResponse productResponse=new ProductResponse();
		productResponse.setProduct(responseProduct);
		productResponse.setMessage("Product Added");
		productResponse.setStatusCode("200");
		productResponse.setStatusMessage("OK");
		logger.debug("End of ProductController");
		return productResponse;
	}
}
