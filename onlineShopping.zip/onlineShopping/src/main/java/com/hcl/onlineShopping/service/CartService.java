package com.hcl.onlineShopping.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.hcl.onlineShopping.entity.Cart;
import com.hcl.onlineShopping.repository.CartRepository;

@Service
public class CartService {
	private static final Logger logger = LoggerFactory.getLogger(CartService.class);
	@Autowired
	CartRepository cartRepository;

	public Cart saveCart(Cart cart) {
		logger.debug("In CartService");
		return cartRepository.save(cart);
	}

}
