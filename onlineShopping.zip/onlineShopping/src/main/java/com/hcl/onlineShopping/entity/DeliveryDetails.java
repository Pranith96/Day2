package com.hcl.onlineShopping.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "deliveryDetails")
public class DeliveryDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "delivery_id")
	private int deliveryId;

	@Column(name = "delivery_address")
	private String deliveryAddress;

	@Column(name = "id")
	private int id;

	@Column(name = "product_id")
	private int productId;

	public int getDeliveryId() {
		return deliveryId;
	}

	public void setDeliveryId(int deliveyId) {
		this.deliveryId = deliveyId;
	}

	public String getDeliveryAddress() {
		return deliveryAddress;
	}

	public void setDeliveryAddress(String deliveryAddress) {
		this.deliveryAddress = deliveryAddress;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

}