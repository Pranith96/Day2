package com.bank.application.bankapplication.service;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import com.bank.application.bankapplication.entity.User;
import com.bank.application.bankapplication.repository.UserRepository;
import com.bank.application.bankapplication.util.BanksConstants;

@Service
@Transactional
@Profile(value = { "local", "dev", "prod" })
public class LoginServiceImpl implements LoginService {

	@Autowired
	UserRepository userRepository;

	@Override
	public void loginCustomer(String userName, String password) throws Exception {

		Optional<User> customerDetails = userRepository.findUserByUserNameAndPassword(userName, password);

		if (!customerDetails.isPresent()) {
			throw new Exception(BanksConstants.DETAILS_NOT_FOUND);
		}
	}
}
