package com.hcl.onlineShopping.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.hcl.onlineShopping.entity.WishList;
import com.hcl.onlineShopping.repository.WishListRepository;

@Service
public class MyWishListService {
	private static final Logger logger = LoggerFactory.getLogger(MyWishListService.class);
	@Autowired
	WishListRepository wishListRepository;

	public List<WishList> myWishListcheck(int id) {
		logger.debug("In MyWishListService");
		return wishListRepository.findAllById(id);

	}
}
