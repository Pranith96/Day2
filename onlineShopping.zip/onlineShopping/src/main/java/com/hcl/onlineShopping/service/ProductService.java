package com.hcl.onlineShopping.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.hcl.onlineShopping.entity.Product;
import com.hcl.onlineShopping.repository.ProductRepository;

@Service
public class ProductService {
	private static final Logger logger = LoggerFactory.getLogger(ProductService.class);
	@Autowired
	ProductRepository productRepository;

	public Product saveProduct(Product product) {
		logger.debug("In ProductService");
		return productRepository.save(product);
	}

}
