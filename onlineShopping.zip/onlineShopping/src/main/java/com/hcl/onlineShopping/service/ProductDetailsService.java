package com.hcl.onlineShopping.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.hcl.onlineShopping.entity.Product;
import com.hcl.onlineShopping.repository.ProductRepository;

@Service
public class ProductDetailsService {
	private static final Logger logger = LoggerFactory.getLogger(ProductDetailsService.class);
	@Autowired
	ProductRepository productRepository;

	public Product productCheck(int productId) {
		logger.debug(" In ProductDetailsService");
		return productRepository.findByProductId(productId);
	}

}
