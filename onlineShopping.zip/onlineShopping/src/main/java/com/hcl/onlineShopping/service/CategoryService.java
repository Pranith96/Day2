package com.hcl.onlineShopping.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.hcl.onlineShopping.entity.Category;
import com.hcl.onlineShopping.repository.CategoryRepository;

@Service
public class CategoryService {
	private static final Logger logger = LoggerFactory.getLogger(CategoryService.class);
	@Autowired
	CategoryRepository categoryRepository;

	public Category saveCategory(Category category) {
		logger.debug("In CategoryService");
		return categoryRepository.save(category);
	}

	public List<Category> displayCategory() {
		logger.debug("In CategoryService");

		return categoryRepository.findAll();
	}

}
