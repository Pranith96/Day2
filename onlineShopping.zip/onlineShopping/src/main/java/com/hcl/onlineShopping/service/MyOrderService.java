package com.hcl.onlineShopping.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.hcl.onlineShopping.entity.Order;
import com.hcl.onlineShopping.repository.OrderRepository;

@Service
public class MyOrderService {
	private static final Logger logger = LoggerFactory.getLogger(MyOrderService.class);
	@Autowired
	OrderRepository orderRepository;

	public List<Order> myOrdercheck(int id) {
		logger.debug(" in MyOrderService");
		return orderRepository.findAllById(id);
	}
}
