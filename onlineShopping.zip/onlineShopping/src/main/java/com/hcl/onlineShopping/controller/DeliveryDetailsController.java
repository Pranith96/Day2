package com.hcl.onlineShopping.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.hcl.onlineShopping.entity.DeliveryDetails;
import com.hcl.onlineShopping.responseModel.OrderResponse;
import com.hcl.onlineShopping.service.DeliveryDetailsService;
@CrossOrigin
@RestController

public class DeliveryDetailsController {
	private static final Logger logger = LoggerFactory.getLogger(DeliveryDetailsController.class);
	@Autowired
	DeliveryDetailsService deliveryDetailsService;

	@PostMapping(value = "delivery/details")
	public OrderResponse showDeliveryDetails(@RequestBody DeliveryDetails deliveryDetails) {
		logger.debug("Start of DeliveryDetails Controller");
		DeliveryDetails responsedelivery = deliveryDetailsService.saveDeliveryDetails(deliveryDetails);
		OrderResponse deliveryResponse = new OrderResponse();
		deliveryResponse.setDeliveryDetails(responsedelivery);
		deliveryResponse.setMessage("Delivery details");
		deliveryResponse.setStatusCode("200");
		deliveryResponse.setStatusMessage("OK");
		logger.debug("End of DeliveryDetails Controller");
		return deliveryResponse;
	}

}
