package com.hcl.onlineShopping.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.hcl.onlineShopping.entity.Cart;
import com.hcl.onlineShopping.responseModel.CartResponse;
import com.hcl.onlineShopping.service.MyCartService;
@CrossOrigin
@RestController
public class MyCartController {

	private static final Logger logger = LoggerFactory.getLogger(MyCartController.class);
	@Autowired
	MyCartService myCartService;

	@GetMapping(value = "/mycart")
	public CartResponse showMyCart(@RequestParam int id) {
		logger.debug("Start of MyCart Controller");
		List<Cart> myCartList = myCartService.myCartcheck(id);
		CartResponse responseCart = new CartResponse();
		responseCart.setCartList(myCartList);
		responseCart.setMessage("Cart List");
		responseCart.setStatusCode("200");
		responseCart.setStatusMessage("OK");
		logger.debug("End of MyCart Controller");
		return responseCart;

	}

}
